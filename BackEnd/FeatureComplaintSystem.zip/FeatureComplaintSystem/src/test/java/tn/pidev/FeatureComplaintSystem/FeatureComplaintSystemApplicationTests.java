package tn.pidev.FeatureComplaintSystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FeatureComplaintSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
