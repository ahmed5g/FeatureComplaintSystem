package tn.pidev.FeatureComplaintSystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FeatureComplaintSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(FeatureComplaintSystemApplication.class, args);
	}

}
